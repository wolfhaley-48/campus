import { useLayoutEffect } from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { Link } from "../navigation";
import {
  Bell,
  CalendarDays,
  FileText,
  GraduationCap,
  LayoutDashboard,
  UserRound,
} from "../icons";

import { useAuth } from "../auth";
import { Avatar } from "./Avatar";
import { Brand, LogoMark } from "./Logo";
import { FullscreenLoader } from "./States";

const GROUPS = [
  {
    label: "Учёба",
    items: [
      { to: "/", label: "Главная", icon: LayoutDashboard, end: true },
      { to: "/schedule", label: "Расписание", icon: CalendarDays },
      { to: "/grades", label: "Успеваемость", icon: GraduationCap },
    ],
  },
  {
    label: "Сервисы",
    items: [
      { to: "/requests", label: "Заявки", icon: FileText },
      { to: "/notifications", label: "Уведомления", icon: Bell, badge: true },
    ],
  },
];

const BOTTOM = [
  { to: "/", label: "Главная", icon: LayoutDashboard, end: true },
  { to: "/schedule", label: "Расписание", icon: CalendarDays },
  { to: "/grades", label: "Оценки", icon: GraduationCap },
  { to: "/requests", label: "Заявки", icon: FileText },
  { to: "/notifications", label: "События", icon: Bell, badge: true },
];

function isRouteActive(pathname, to, end) {
  if (end) return pathname === to;
  return pathname === to || pathname.startsWith(`${to}/`);
}

function NavLinkItem({ item, unread }) {
  const { pathname } = useLocation();
  const active = isRouteActive(pathname, item.to, item.end);
  const Icon = item.icon;
  return (
    <Link
      to={item.to}
      className="nav-link"
      data-active={active ? "true" : undefined}
      aria-current={active ? "page" : undefined}
      title={item.label}
    >
      <Icon strokeWidth={1.8} aria-hidden="true" />
      <span>{item.label}</span>
      {item.badge && unread > 0 && (
        <span className="nav-badge" aria-label={`${unread} непрочитанных`}>
          {unread > 9 ? "9+" : unread}
        </span>
      )}
    </Link>
  );
}

function Sidebar() {
  const { user, unread, logout } = useAuth();
  const { pathname } = useLocation();

  return (
    <aside className="sidebar">
      <Brand />

      <nav className="sidebar-nav" aria-label="Основная навигация">
        {GROUPS.map((group) => (
          <div className="nav-group" key={group.label}>
            <span className="nav-label">{group.label}</span>
            {group.items.map((item) => (
              <NavLinkItem key={item.to} item={item} unread={unread} />
            ))}
          </div>
        ))}
        <div className="nav-group">
          <span className="nav-label">Профиль</span>
          <Link
            to="/profile"
            className="nav-link"
            data-active={pathname === "/profile" ? "true" : undefined}
            aria-current={pathname === "/profile" ? "page" : undefined}
          >
            <UserRound strokeWidth={1.8} aria-hidden="true" />
            <span>Личные данные</span>
          </Link>
        </div>
      </nav>

      <div className="sidebar-foot">
        <Link to="/profile" className="profile-chip">
          <Avatar user={user} size="sm" dark />
          <span className="profile-chip-text">
            <span className="profile-chip-name">{user?.fullName}</span>
            <span className="profile-chip-meta">
              {user?.group} · {user?.course} курс
            </span>
          </span>
        </Link>
        <button type="button" className="sidebar-logout" onClick={logout}>
          Выйти из аккаунта
        </button>
        <p className="sidebar-note">
          Демо-прототип для конкурса. Неофициальный сервис университета. Данные вымышлены.
        </p>
      </div>
    </aside>
  );
}

function MobileHeader() {
  const { user, unread } = useAuth();
  return (
    <header className="mobile-header">
      <Link to="/" className="mobile-brand" aria-label="кампус, на главную">
        <LogoMark size={32} />
        <span className="brand-word">кампус</span>
      </Link>
      <div className="mobile-actions">
        <Link to="/notifications" className="icon-btn" aria-label="Уведомления">
          <Bell size={18} strokeWidth={1.9} aria-hidden="true" />
          {unread > 0 && <span className="icon-dot" />}
        </Link>
        <Link to="/profile" aria-label="Профиль">
          <Avatar user={user} size="sm" />
        </Link>
      </div>
    </header>
  );
}

function BottomNav() {
  const { pathname } = useLocation();
  const { unread } = useAuth();
  return (
    <nav className="bottom-nav" aria-label="Мобильная навигация">
      {BOTTOM.map((item) => {
        const active = isRouteActive(pathname, item.to, item.end);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            className="bottom-link"
            data-active={active ? "true" : undefined}
            aria-current={active ? "page" : undefined}
          >
            <span className="bottom-link-icon">
              <Icon strokeWidth={1.9} aria-hidden="true" />
              {item.badge && unread > 0 && (
                <span className="bottom-badge">{unread > 9 ? "9+" : unread}</span>
              )}
            </span>
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export default function Layout() {
  const { user, loading } = useAuth();
  const location = useLocation();

  useLayoutEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [location.pathname]);

  if (loading) return <FullscreenLoader />;
  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  return (
    <div className="shell">
      <a className="skip-link" href="#main-content">
        Перейти к содержимому
      </a>
      <Sidebar />
      <div className="main">
        <MobileHeader />
        <main className="main-inner" id="main-content">
          <Outlet />
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
