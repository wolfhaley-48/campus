import { Link } from "../navigation";
import { Compass } from "../icons";

export default function NotFound() {
  return (
    <div className="page notfound">
      <span className="notfound-code">404</span>
      <span className="notfound-icon">
        <Compass size={26} strokeWidth={1.7} aria-hidden="true" />
      </span>
      <h1>Страница не найдена</h1>
      <p>Проверьте адрес или вернитесь на главную. Ссылка могла устареть.</p>
      <Link to="/" className="btn btn-primary">
        На главную
      </Link>
    </div>
  );
}
