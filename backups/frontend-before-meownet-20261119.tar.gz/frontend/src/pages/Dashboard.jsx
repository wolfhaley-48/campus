import { Link } from "../navigation";
import {
  ArrowUpRight,
  CalendarOff,
  Check,
  Clock3,
  FileText,
  MapPin,
  Plus,
} from "../icons";

import { useAuth } from "../auth";
import { ChangeNote } from "../components/ChangeNote";
import { PageHeader } from "../components/PageHeader";
import { EmptyState, ErrorState } from "../components/States";
import { useApi } from "../useApi";
import {
  MONTHS_SHORT,
  daysUntil,
  daysWord,
  dayLabel,
  formatDayShort,
  formatFullDate,
  requestStatusTone,
  lessonTypeTone,
  timeAgo,
} from "../utils";

const SESSION_START = "2026-12-15";

function DashboardSkeleton() {
  return (
    <div className="page" aria-busy="true" aria-label="Загрузка главной">
      <div className="stack" style={{ gap: 10 }}>
        <div className="skeleton" style={{ width: 120, height: 10 }} />
        <div className="skeleton" style={{ width: 300, height: 36 }} />
      </div>
      <div className="dash-grid">
        <div className="dash-col">
          <div className="skeleton" style={{ height: 200, borderRadius: 24 }} />
          <div className="stats-grid">
            {[0, 1, 2, 3].map((item) => (
              <div key={item} className="skeleton" style={{ height: 104, borderRadius: 20 }} />
            ))}
          </div>
          <div className="skeleton" style={{ height: 260, borderRadius: 24 }} />
        </div>
        <div className="dash-col">
          <div className="skeleton" style={{ height: 200, borderRadius: 24 }} />
          <div className="skeleton" style={{ height: 190, borderRadius: 24 }} />
          <div className="skeleton" style={{ height: 190, borderRadius: 24 }} />
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, suffix, note, progress, tone = "default" }) {
  return (
    <div className="stat-card" data-tone={tone}>
      <span className="stat-label">{label}</span>
      <div className="stat-value-row">
        <span className="stat-value">{value}</span>
        {suffix && <span className="stat-suffix">{suffix}</span>}
      </div>
      {typeof progress === "number" && (
        <div className="stat-bar" aria-hidden="true">
          <span style={{ width: `${Math.min(100, Math.max(0, progress))}%` }} />
        </div>
      )}
      {note && <span className="stat-note">{note}</span>}
    </div>
  );
}

function TodayLesson({ lesson }) {
  return (
    <div className="today-lesson" data-status={lesson.status || "upcoming"}>
      <div className="today-time">
        <span>{lesson.start}</span>
        <small>{lesson.end}</small>
      </div>
      <div className="today-body">
        <div className="today-subject">{lesson.subject}</div>
        <div className="today-meta">
          <span>
            <MapPin size={12} strokeWidth={2} aria-hidden="true" />
            ауд. {lesson.room}, {lesson.building}
          </span>
          <span>{lesson.teacher}</span>
        </div>
        <ChangeNote change={lesson.change} compact />
      </div>
      <div className="today-side">
        <span className={`type-pill type-${lessonTypeTone(lesson.type)}`}>{lesson.type}</span>
        {lesson.status === "now" && <span className="pill pill-accent accent-now">Сейчас</span>}
        {lesson.status === "cancelled" && <span className="pill pill-danger">Отменено</span>}
      </div>
    </div>
  );
}

function DeadlinesCard({ deadlines, today }) {
  return (
    <section className="card">
      <div className="card-head">
        <h2 className="card-title">Дедлайны</h2>
        <Link to="/notifications" className="card-link">
          Напоминания <ArrowUpRight size={13} aria-hidden="true" />
        </Link>
      </div>

      {deadlines.length === 0 ? (
        <EmptyState
          icon={Check}
          title="Дедлайнов нет"
          text="Ближайшие сроки появятся здесь."
        />
      ) : (
        <ul className="deadline-list">
          {deadlines.map((item) => {
            const days = daysUntil(item.dueDate);
            const urgent = days !== null && days <= 3;
            return (
              <li key={item.id} className="deadline-item">
                <span className="deadline-date" data-urgent={urgent ? "true" : undefined}>
                  <b>{Number(item.dueDate.slice(8, 10))}</b>
                  <small>{MONTHS_SHORT[Number(item.dueDate.slice(5, 7)) - 1]}</small>
                </span>
                <span className="deadline-text">
                  <span className="deadline-title">{item.title}</span>
                  <span className="deadline-when" data-urgent={urgent ? "true" : undefined}>
                    {days === 0
                      ? "сегодня"
                      : days === 1
                        ? "завтра"
                        : `${days} ${daysWord(days)}`}
                  </span>
                </span>
              </li>
            );
          })}
        </ul>
      )}
      <p className="card-footnote">
        Сегодня {formatDayShort(today)}. Напоминания приходят в «Уведомления».
      </p>
    </section>
  );
}

function RequestsCard({ requests }) {
  return (
    <section className="card">
      <div className="card-head">
        <h2 className="card-title">Заявки</h2>
        <Link to="/requests" className="card-link">
          Все <ArrowUpRight size={13} aria-hidden="true" />
        </Link>
      </div>

      {requests.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="Заявок пока нет"
          text="Справка или заявление занимают пару минут."
          action={
            <Link to="/requests?new=1" className="btn btn-soft btn-sm">
              <Plus size={14} aria-hidden="true" /> Создать
            </Link>
          }
        />
      ) : (
        <div className="mini-request-list">
          {requests.map((item) => (
            <Link to={`/requests/${item.id}`} className="mini-request" key={item.id}>
              <span className="mini-request-main">
                <span className="mini-request-type">{item.typeLabel}</span>
                <span className="mini-request-number">{item.number}</span>
              </span>
              <span className={`pill pill-${requestStatusTone(item.status)} pill-status`}>
                {item.statusLabel}
              </span>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}

function AnnouncementsCard({ notifications }) {
  return (
    <section className="card">
      <div className="card-head">
        <h2 className="card-title">Объявления</h2>
        <Link to="/notifications" className="card-link">
          Все <ArrowUpRight size={13} aria-hidden="true" />
        </Link>
      </div>

      {notifications.length === 0 ? (
        <EmptyState icon={CalendarOff} title="Пока тихо" text="Новости деканата появятся здесь." />
      ) : (
        <ul className="announce-list">
          {notifications.map((item) => (
            <li key={item.id}>
              <Link to="/notifications" className="announce-item">
                <span className="announce-text">
                  <span className="announce-title">{item.title}</span>
                  <span className="announce-meta">
                    {!item.isRead && <span className="unread-dot" aria-label="Не прочитано" />}
                    {timeAgo(item.createdAt)}
                  </span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { data, loading, error, reload } = useApi("/dashboard");

  if (loading) return <DashboardSkeleton />;

  if (error) {
    return (
      <div className="page">
        <PageHeader eyebrow="Личный кабинет" title={`Привет, ${user.firstName}`} />
        <ErrorState onRetry={reload} />
      </div>
    );
  }

  const sessionDays = daysUntil(SESSION_START);
  const next = data.nextLesson;
  const nextDateLabel = next ? dayLabel(next.date, data.today.date) : "";
  const nextWhen =
    nextDateLabel === "Сегодня" || nextDateLabel === "Завтра"
      ? nextDateLabel
      : formatDayShort(next?.date);

  return (
    <div className="page">
      <PageHeader
        eyebrow={`${user.group} · ${user.course} курс`}
        title={`Привет, ${user.firstName}`}
        subtitle={`${formatFullDate(data.today.date)}. ${data.today.lessons.length > 0 ? `Занятий сегодня: ${data.today.lessons.length}.` : "Сегодня занятий нет."}`}
        actions={
          <>
            {sessionDays !== null && sessionDays >= 0 && (
              <span className="pill pill-lime session-pill">
                До сессии {sessionDays} {daysWord(sessionDays)}
              </span>
            )}
            <Link to="/requests?new=1" className="btn btn-primary">
              <Plus size={16} strokeWidth={2.2} aria-hidden="true" />
              Заявка
            </Link>
          </>
        }
      />

      <div className="dash-grid">
        <div className="dash-col">
          <section className="next-card">
            <div className="next-top">
              <span className="next-label">Ближайшее занятие</span>
              {next && <span className="pill pill-lime">{nextWhen}</span>}
            </div>

            {next ? (
              <>
                <h2 className="next-subject">{next.lesson.subject}</h2>
                <div className="next-meta">
                  <span>
                    <Clock3 size={14} strokeWidth={2} aria-hidden="true" />
                    {next.lesson.start}–{next.lesson.end}
                  </span>
                  <span>
                    <MapPin size={14} strokeWidth={2} aria-hidden="true" />
                    ауд. {next.lesson.room}, {next.lesson.building}
                  </span>
                </div>
                <p className="next-teacher">{next.lesson.teacher}</p>
                <ChangeNote change={next.lesson.change} />
                <div className="next-foot">
                  <Link to="/schedule" className="next-link">
                    Расписание на неделю <ArrowUpRight size={15} aria-hidden="true" />
                  </Link>
                  <span className="next-type">{next.lesson.type}</span>
                </div>
              </>
            ) : (
              <div className="next-empty">
                <span>Занятий на ближайшие дни нет.</span>
                <Link to="/schedule" className="next-link">
                  Открыть расписание <ArrowUpRight size={15} aria-hidden="true" />
                </Link>
              </div>
            )}
          </section>

          <div className="stats-grid">
            <StatCard
              label="Средний балл"
              value={data.stats.average ?? "—"}
              note="по последней сессии"
            />
            <StatCard
              label="Закрыто в семестре"
              value={data.stats.creditsEarned}
              suffix={`из ${data.stats.creditsTotal} з.е.`}
              progress={
                data.stats.creditsTotal
                  ? (data.stats.creditsEarned / data.stats.creditsTotal) * 100
                  : 0
              }
              note="зачёты и экзамены"
            />
            <StatCard
              label="Задолженности"
              value={data.stats.debts}
              note={data.stats.debts === 0 ? "Всё закрыто" : "Есть пересдачи"}
              tone={data.stats.debts === 0 ? "success" : "warn"}
            />
            <StatCard
              label="Посещение"
              value={`${data.stats.attendance}%`}
              progress={data.stats.attendance}
              note="сентябрь — ноябрь"
            />
          </div>

          <section className="card">
            <div className="card-head">
              <div className="card-title-row">
                <h2 className="card-title">Сегодня</h2>
                <span className="pill pill-neutral">{formatDayShort(data.today.date)}</span>
              </div>
              <Link to="/schedule" className="card-link">
                Вся неделя <ArrowUpRight size={13} aria-hidden="true" />
              </Link>
            </div>

            {data.today.lessons.length === 0 ? (
              <EmptyState
                icon={CalendarOff}
                title="Занятий нет"
                text={
                  next
                    ? `Следующее занятие — ${nextWhen.toLowerCase()} в ${next.lesson.start}.`
                    : "Ближайшие занятия появятся в расписании."
                }
              />
            ) : (
              <div className="today-list">
                {data.today.lessons.map((lesson) => (
                  <TodayLesson key={lesson.id} lesson={lesson} />
                ))}
              </div>
            )}
          </section>
        </div>

        <aside className="dash-col">
          <DeadlinesCard deadlines={data.deadlines} today={data.today.date} />
          <RequestsCard requests={data.requests} />
          <AnnouncementsCard notifications={data.notifications} />
        </aside>
      </div>
    </div>
  );
}
