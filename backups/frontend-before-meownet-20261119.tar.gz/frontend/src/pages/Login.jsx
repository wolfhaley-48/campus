import { useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { ArrowRight, Clock3, ShieldCheck } from "../icons";
import { Link, useAppNavigate } from "../navigation";

import { useAuth } from "../auth";
import { Field } from "../bencho/Field";
import { LogoMark } from "../components/Logo";
import { FullscreenLoader } from "../components/States";
import { useToast } from "../toast";
import { formatFullDate, todayIso } from "../utils";

const PASSWORD = "kampus2026";

const DEMO_ACCOUNTS = [
  {
    login: "anna",
    name: "Анна Смирнова",
    meta: "3 курс · ПИ-23-1 · цифровые технологии",
    hue: 218,
  },
  {
    login: "maksim",
    name: "Максим Орлов",
    meta: "2 курс · ЭК-24-2 · экономика",
    hue: 28,
  },
];

export default function Login() {
  const { user, loading, login } = useAuth();
  const navigate = useAppNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const [loginValue, setLoginValue] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (loading) return <FullscreenLoader />;
  if (user) return <Navigate to="/" replace />;

  const submit = async (event) => {
    event.preventDefault();
    if (!loginValue.trim() || !password) {
      setError("Введите логин и пароль.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await login(loginValue.trim().toLowerCase(), password);
      const target = location.state?.from || "/";
      navigate(target, { replace: true });
    } catch (requestError) {
      setError(requestError.message || "Не удалось войти. Проверьте логин и пароль.");
    } finally {
      setBusy(false);
    }
  };

  const fillDemo = (account) => {
    setLoginValue(account.login);
    setPassword(PASSWORD);
    setError("");
    toast({
      kind: "info",
      title: "Данные подставлены",
      body: `Аккаунт ${account.name}. Нажмите «Войти».`,
    });
  };

  return (
    <div className="login">
      <aside className="login-stage">
        <div className="login-stage-top">
          <Link to="/" className="login-brand" aria-label="кампус">
            <LogoMark size={36} />
            <span className="brand-word">кампус</span>
          </Link>
          <span className="login-demo-pill">демо · конкурс</span>
        </div>

        <div className="login-copy">
          <p className="eyebrow">Личный кабинет студента</p>
          <h1>Деканат без очередей.</h1>
          <p>
            Расписание с переносами, оценки, справки и объявления — в одном кабинете.
            Каждый студент видит только свою запись.
          </p>
        </div>

        <div className="login-preview" aria-hidden="true">
          <div className="preview-card">
            <div className="preview-head">
              <span className="preview-day">Сегодня</span>
              <span>{formatFullDate(todayIso())}</span>
            </div>
            <div className="preview-row">
              <span className="preview-time">09:00</span>
              <div>
                <b>Математический анализ</b>
                <small>ауд. 214 · корпус А · доц. Ковалёв</small>
              </div>
            </div>
            <div className="preview-row preview-row-active">
              <span className="preview-time">10:45</span>
              <div>
                <b>Базы данных</b>
                <small>ауд. 308 · корпус Б · лаборатория</small>
              </div>
              <span className="preview-now">сейчас</span>
            </div>
            <div className="preview-row">
              <span className="preview-time">12:45</span>
              <div>
                <b>Физика</b>
                <small>ауд. 117 · корпус А · практика</small>
              </div>
            </div>
          </div>
        </div>

        <p className="login-disclaimer">
          Демо-прототип для конкурса. Неофициальный сервис университета. ФИО, оценки,
          номера зачёток и заявки вымышлены.
        </p>
      </aside>

      <main className="login-form-side">
        <div className="login-form-wrap">
          <div className="login-mobile-brand">
            <LogoMark size={32} />
            <span className="brand-word">кампус</span>
          </div>

          <div className="login-form-head">
            <p className="eyebrow">Вход</p>
            <h2>Личный кабинет</h2>
            <p>Введите логин и пароль или выберите тестовый аккаунт.</p>
          </div>

          <form className="login-form" onSubmit={submit} noValidate>
            <Field
              label="Логин"
              value={loginValue}
              onChange={setLoginValue}
              autoComplete="username"
              name="login"
              required
            />
            <Field
              label="Пароль"
              type="password"
              value={password}
              onChange={setPassword}
              autoComplete="current-password"
              name="password"
              required
            />

            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}

            <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={busy}>
              {busy ? "Входим…" : "Войти"}
              {!busy && <ArrowRight size={17} strokeWidth={2.2} aria-hidden="true" />}
            </button>
          </form>

          <section className="demo-block" aria-labelledby="demo-title">
            <div className="demo-head">
              <span id="demo-title">Тестовые аккаунты</span>
              <code>пароль: {PASSWORD}</code>
            </div>
            <div className="demo-list">
              {DEMO_ACCOUNTS.map((account) => (
                <button
                  type="button"
                  className="demo-account"
                  key={account.login}
                  onClick={() => fillDemo(account)}
                >
                  <span
                    className="demo-avatar"
                    style={{ "--hue": account.hue }}
                    aria-hidden="true"
                  >
                    {account.name
                      .split(" ")
                      .map((part) => part[0])
                      .join("")}
                  </span>
                  <span className="demo-account-text">
                    <b>{account.name}</b>
                    <small>{account.meta}</small>
                  </span>
                  <span className="demo-login">{account.login}</span>
                </button>
              ))}
            </div>
            <p className="demo-note">
              У аккаунтов разные факультеты, расписание, оценки и заявки. Войдите под
              каждым, чтобы сравнить.
            </p>
          </section>

          <div className="login-security">
            <ShieldCheck size={17} strokeWidth={1.9} aria-hidden="true" />
            <span>Пароль хранится в виде scrypt-хеша. Сессия — в httpOnly-cookie.</span>
          </div>

          <p className="login-footnote">
            <Clock3 size={13} strokeWidth={1.9} aria-hidden="true" />
            Прототип работает до 28 ноября, без VPN.
          </p>

          <p className="login-mobile-note">
            Демо-прототип для конкурса. Неофициальный сервис университета. ФИО, оценки
            и заявки вымышлены.
          </p>
        </div>
      </main>
    </div>
  );
}
