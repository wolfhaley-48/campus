import { useEffect, useState } from "react";
import {
  CalendarDays,
  CalendarOff,
  ChevronLeft,
  ChevronRight,
  MapPin,
} from "../icons";

import { ChangeNote } from "../components/ChangeNote";
import { PageHeader } from "../components/PageHeader";
import { EmptyState, ErrorState } from "../components/States";
import { useApi } from "../useApi";
import {
  WEEKDAYS,
  WEEKDAYS_SHORT,
  formatDateRange,
  formatDayMonth,
  lessonTypeTone,
  plural,
} from "../utils";

function ScheduleSkeleton() {
  return (
    <div className="page" aria-busy="true" aria-label="Загрузка расписания">
      <div className="stack" style={{ gap: 10 }}>
        <div className="skeleton" style={{ width: 90, height: 10 }} />
        <div className="skeleton" style={{ width: 240, height: 34 }} />
      </div>
      <div className="skeleton" style={{ height: 54, borderRadius: 999 }} />
      <div className="schedule-skeleton">
        {[0, 1, 2, 3, 4].map((item) => (
          <div key={item} className="skeleton" style={{ height: 260, borderRadius: 20 }} />
        ))}
      </div>
    </div>
  );
}

function LessonCard({ lesson, wide = false }) {
  const cancelled = lesson.change?.kind === "cancelled";
  return (
    <article
      className={`sched-lesson${wide ? " sched-lesson-wide" : ""}${cancelled ? " is-cancelled" : ""}`}
    >
      <div className="sched-lesson-top">
        <span className="sched-time">
          {lesson.start}
          <span>{lesson.end}</span>
        </span>
        <span className={`type-pill type-${lessonTypeTone(lesson.type)}`}>{lesson.type}</span>
      </div>
      <h3 className="sched-subject">{lesson.subject}</h3>
      <p className="sched-place">
        <MapPin size={12} strokeWidth={2} aria-hidden="true" />
        ауд. {lesson.room}, {lesson.building}
      </p>
      <p className="sched-teacher">{lesson.teacher}</p>
      <ChangeNote change={lesson.change} />
    </article>
  );
}

function DayColumn({ day }) {
  return (
    <section className={`week-day${day.isToday ? " is-today" : ""}`}>
      <header className="week-day-head">
        <span className="week-day-name">{WEEKDAYS[day.weekday - 1]}</span>
        <span className="week-day-date">{Number(day.date.slice(8, 10))}</span>
        {day.isToday && <span className="week-today-mark">сегодня</span>}
      </header>
      <div className="week-day-body">
        {day.lessons.length === 0 ? (
          <p className="week-day-empty">Занятий нет</p>
        ) : (
          day.lessons.map((lesson) => <LessonCard key={lesson.id} lesson={lesson} />)
        )}
      </div>
    </section>
  );
}

export default function Schedule() {
  const [offset, setOffset] = useState(0);
  const [activeDate, setActiveDate] = useState(null);
  const [view, setView] = useState("day");
  const { data, loading, error, reload } = useApi(`/schedule?week=${offset}`);

  useEffect(() => {
    if (!data) return;
    const today = data.days.find((day) => day.isToday);
    setActiveDate(today ? today.date : data.days[0].date);
  }, [data]);

  if (loading && !data) return <ScheduleSkeleton />;

  if (error) {
    return (
      <div className="page">
        <PageHeader eyebrow="Учёба" title="Расписание" />
        <ErrorState onRetry={reload} />
      </div>
    );
  }

  const lessonCount = data.days.reduce((sum, day) => sum + day.lessons.length, 0);
  const changeCount = data.days.reduce(
    (sum, day) => sum + day.lessons.filter((lesson) => lesson.change).length,
    0,
  );
  const activeDay = data.days.find((day) => day.date === activeDate) || data.days[0];

  return (
    <div className="page">
      <PageHeader
        title="Расписание"
        actions={
          <div className="week-nav">
            <button
              type="button"
              className="icon-btn"
              onClick={() => setOffset((value) => value - 1)}
              aria-label="Предыдущая неделя"
            >
              <ChevronLeft size={18} strokeWidth={2} aria-hidden="true" />
            </button>
            <span className="week-nav-label">
              {formatDateRange(data.weekStart, data.weekEnd)}
            </span>
            <button
              type="button"
              className="icon-btn"
              onClick={() => setOffset((value) => value + 1)}
              aria-label="Следующая неделя"
            >
              <ChevronRight size={18} strokeWidth={2} aria-hidden="true" />
            </button>
            {offset !== 0 && (
              <button type="button" className="btn btn-soft btn-sm" onClick={() => setOffset(0)}>
                Эта неделя
              </button>
            )}
          </div>
        }
      />

      <div className="agenda-toolbar"><div className="schedule-summary">
        <span>
          <CalendarDays size={15} strokeWidth={1.9} aria-hidden="true" />
          {lessonCount} {plural(lessonCount, "занятие", "занятия", "занятий")}
        </span>
        {changeCount > 0 ? (
          <span className="schedule-changes">
            {changeCount} {plural(changeCount, "изменение", "изменения", "изменений")}
          </span>
        ) : (
          <span className="muted">Без изменений</span>
        )}
        <span className="muted schedule-summary-date">
          Сегодня, {formatDayMonth(data.today)}
        </span>
      </div>

      <div className="schedule-view-controls">
        <div className="segmented" role="group" aria-label="Вид расписания">
          <button type="button" className="segmented-btn" data-active={view === "day" || undefined} aria-pressed={view === "day"} onClick={() => setView("day")}>По дням</button>
          <button type="button" className="segmented-btn" data-active={view === "week" || undefined} aria-pressed={view === "week"} onClick={() => setView("week")}>Вся неделя</button>
        </div>
      </div>
      </div>

      {view === "day" && <div className="mobile-day-picker panel-day-picker" aria-label="День недели">
        {data.days.map((day) => (
          <button
            key={day.date}
            type="button"
            className="day-chip"
            data-active={day.date === activeDate ? "true" : undefined}
            data-today={day.isToday ? "true" : undefined}
            aria-pressed={day.date === activeDate}
            aria-label={`${WEEKDAYS[day.weekday - 1]}, ${formatDayMonth(day.date)}${day.isToday ? ", сегодня" : ""}`}
            onClick={() => setActiveDate(day.date)}
          >
            <span>{WEEKDAYS_SHORT[day.weekday - 1]}</span>
            <b>{Number(day.date.slice(8, 10))}</b>
            {day.lessons.some((lesson) => lesson.change) && <i className="day-chip-dot" />}
          </button>
        ))}
      </div>}

      {view === "week" && <div className="week-board panel-week-board">
        {data.days.map((day) => (
          <DayColumn key={day.date} day={day} />
        ))}
      </div>}

      {view === "day" && <div className="day-focus panel-day-focus">
        <div className="day-focus-head">
          <div>
            <p className="eyebrow">{WEEKDAYS[activeDay.weekday - 1]}</p>
            <h2 className="day-focus-title">{formatDayMonth(activeDay.date)}</h2>
          </div>
          {activeDay.isToday && <span className="pill pill-accent">Сегодня</span>}
        </div>

        {activeDay.lessons.length === 0 ? (
          <div className="card">
            <EmptyState
              icon={CalendarOff}
              title="Занятий нет"
            />
          </div>
        ) : (
          <div className="day-focus-list">
            {activeDay.lessons.map((lesson) => (
              <LessonCard key={lesson.id} lesson={lesson} wide />
            ))}
          </div>
        )}
      </div>}
    </div>
  );
}
