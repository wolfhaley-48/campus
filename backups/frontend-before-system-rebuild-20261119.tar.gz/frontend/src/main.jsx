import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";

import "@fontsource-variable/inter";

import "./styles/tokens.css";
import "./styles/base.css";
import "./styles/pages.css";
import "./styles/meow-theme.css";
import "./styles/transitions.css";

import App from "./App";
import { AuthProvider } from "./auth";
import { NavigationProvider } from "./navigation";
import { ToastProvider } from "./toast";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter useTransitions={false}>
      <NavigationProvider>
        <ToastProvider>
          <AuthProvider>
            <App />
          </AuthProvider>
        </ToastProvider>
      </NavigationProvider>
    </BrowserRouter>
  </React.StrictMode>,
);
