import { useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { ArrowRight, Clock3, ShieldCheck } from "../icons";
import { Link, useAppNavigate } from "../navigation";

import { useAuth } from "../auth";
import { Field } from "../bencho/Field";
import { LogoMark } from "../components/Logo";
import { FullscreenLoader } from "../components/States";
import { useToast } from "../toast";

const PASSWORD = "kampus2026";

const DEMO_ACCOUNTS = [
  {
    login: "anna",
    name: "Анна Смирнова",
    meta: "3 курс · ПИ-23-1 · цифровые технологии",
    hue: 218,
  },
  {
    login: "maksim",
    name: "Максим Орлов",
    meta: "2 курс · ЭК-24-2 · экономика",
    hue: 28,
  },
];

export default function Login() {
  const { user, loading, login } = useAuth();
  const navigate = useAppNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const [loginValue, setLoginValue] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (loading) return <FullscreenLoader />;
  if (user) return <Navigate to="/" replace />;

  const submit = async (event) => {
    event.preventDefault();
    if (!loginValue.trim() || !password) {
      setError("Введите логин и пароль.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await login(loginValue.trim().toLowerCase(), password);
      const target = location.state?.from || "/";
      navigate(target, { replace: true });
    } catch (requestError) {
      setError(requestError.message || "Не удалось войти. Проверьте логин и пароль.");
    } finally {
      setBusy(false);
    }
  };

  const fillDemo = (account) => {
    setLoginValue(account.login);
    setPassword(PASSWORD);
    setError("");
    toast({
      kind: "info",
      title: "Данные подставлены",
      body: `Аккаунт ${account.name}. Нажмите «Войти».`,
    });
  };

  return (
    <div className="login">
      <main className="login-form-side">
        <div className="login-form-wrap">
          <div className="login-mobile-brand">
            <LogoMark size={32} />
            <span className="brand-word">кампус</span>
          </div>

          <div className="login-form-head">
            <p className="eyebrow">Личный кабинет студента</p>
            <h1>Войти в кампус</h1>
            <p>Введите логин и пароль или выберите тестовый аккаунт.</p>
          </div>

          <form className="login-form" onSubmit={submit} noValidate>
            <Field
              label="Логин"
              value={loginValue}
              onChange={setLoginValue}
              autoComplete="username"
              name="login"
              required
            />
            <Field
              label="Пароль"
              type="password"
              value={password}
              onChange={setPassword}
              autoComplete="current-password"
              name="password"
              required
            />

            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}

            <button type="submit" className="btn btn-primary btn-lg btn-block" disabled={busy}>
              {busy ? "Входим…" : "Войти"}
              {!busy && <ArrowRight size={17} strokeWidth={2.2} aria-hidden="true" />}
            </button>
          </form>

          <details className="demo-block account-picker">
            <summary className="demo-head">
              <span id="demo-title">Тестовые аккаунты</span>
            </summary>
            <div className="demo-list">
              {DEMO_ACCOUNTS.map((account) => (
                <button
                  type="button"
                  className="demo-account"
                  key={account.login}
                  onClick={() => fillDemo(account)}
                >
                  <span
                    className="demo-avatar"
                    style={{ "--hue": account.hue }}
                    aria-hidden="true"
                  >
                    {account.name
                      .split(" ")
                      .map((part) => part[0])
                      .join("")}
                  </span>
                  <span className="demo-account-text">
                    <b>{account.name}</b>
                    <small>{account.meta}</small>
                  </span>
                  <span className="demo-login">{account.login}</span>
                </button>
              ))}
            </div>
            <p className="demo-note">
              Выберите студента, чтобы подставить логин и пароль.
            </p>
          </details>

          <div className="login-security">
            <ShieldCheck size={17} strokeWidth={1.9} aria-hidden="true" />
            <span>Пароль хранится в виде scrypt-хеша. Сессия — в httpOnly-cookie.</span>
          </div>

          <p className="login-footnote">
            <Clock3 size={13} strokeWidth={1.9} aria-hidden="true" />
            Прототип работает до 28 ноября, без VPN.
          </p>

          <p className="login-mobile-note">
            Демо-прототип для конкурса. Неофициальный сервис университета. ФИО, оценки
            и заявки вымышлены.
          </p>
        </div>
      </main>
    </div>
  );
}
