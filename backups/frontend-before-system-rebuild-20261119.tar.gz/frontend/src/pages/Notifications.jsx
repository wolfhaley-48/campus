import { useEffect, useMemo, useState } from "react";
import { BellOff, CheckCheck, Inbox } from "../icons";

import { api } from "../api";
import { useAuth } from "../auth";
import { PageHeader } from "../components/PageHeader";
import { EmptyState, ErrorState } from "../components/States";
import { useToast } from "../toast";
import { useApi } from "../useApi";
import {
  categoryLabel,
  daysUntil,
  daysWord,
  formatDayMonth,
  timeAgo,
  todayIso,
} from "../utils";

const FILTERS = [
  { key: "all", label: "Все" },
  { key: "dean", label: "Деканат" },
  { key: "schedule", label: "Расписание" },
  { key: "deadline", label: "Дедлайны" },
  { key: "request", label: "Заявки" },
];

function dayKey(iso) {
  const date = new Date(iso);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function groupLabel(key, today) {
  if (key === today) return "Сегодня";
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayKey = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, "0")}-${String(yesterday.getDate()).padStart(2, "0")}`;
  if (key === yesterdayKey) return "Вчера";
  return formatDayMonth(key);
}

function NotificationSkeleton() {
  return (
    <div className="page" aria-busy="true" aria-label="Загрузка уведомлений">
      <div className="stack" style={{ gap: 10 }}>
        <div className="skeleton" style={{ width: 120, height: 10 }} />
        <div className="skeleton" style={{ width: 260, height: 34 }} />
      </div>
      <div className="skeleton" style={{ height: 46, borderRadius: 999, width: 420 }} />
      {[0, 1, 2].map((item) => (
        <div key={item} className="skeleton" style={{ height: 110, borderRadius: 20 }} />
      ))}
    </div>
  );
}

export default function Notifications() {
  const { data, loading, error, reload } = useApi("/notifications");
  const { refreshUnread } = useAuth();
  const { toast } = useToast();
  const [filter, setFilter] = useState("all");
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (data) setItems(data.notifications);
  }, [data]);

  const unread = items.filter((item) => !item.isRead).length;
  const counts = FILTERS.reduce((acc, item) => {
    acc[item.key] =
      item.key === "all"
        ? items.length
        : items.filter((notification) => notification.category === item.key).length;
    return acc;
  }, {});

  const filtered = items.filter(
    (item) => filter === "all" || item.category === filter,
  );

  const groups = useMemo(() => {
    const today = todayIso();
    const map = new Map();
    for (const item of filtered) {
      const key = dayKey(item.createdAt);
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(item);
    }
    return [...map.entries()].map(([key, list]) => ({
      key,
      label: groupLabel(key, today),
      items: list,
    }));
  }, [filtered]);

  if (loading && !data) return <NotificationSkeleton />;

  if (error) {
    return (
      <div className="page">
        <PageHeader eyebrow="Сервисы" title="Уведомления" />
        <ErrorState onRetry={reload} />
      </div>
    );
  }

  const markRead = async (notification) => {
    if (notification.isRead) return;
    setItems((current) =>
      current.map((item) =>
        item.id === notification.id ? { ...item, isRead: true } : item,
      ),
    );
    try {
      await api.post(`/notifications/${notification.id}/read`);
      refreshUnread();
    } catch {
      setItems((current) =>
        current.map((item) =>
          item.id === notification.id ? { ...item, isRead: false } : item,
        ),
      );
    }
  };

  const markAll = async () => {
    try {
      await api.post("/notifications/read-all");
      setItems((current) => current.map((item) => ({ ...item, isRead: true })));
      refreshUnread();
      toast({ kind: "success", title: "Всё прочитано", body: "Счётчик уведомлений обнулён." });
    } catch (requestError) {
      toast({
        kind: "error",
        title: "Не удалось обновить",
        body: requestError.message,
      });
    }
  };

  return (
    <div className="page">
      <PageHeader
        eyebrow="Сервисы"
        title="Уведомления"
        subtitle="Объявления деканата, переносы занятий, дедлайны и статусы заявок."
        actions={
          <>
            {unread > 0 && (
              <span className="pill pill-accent">
                {unread} {unread === 1 ? "непрочитанное" : "непрочитанных"}
              </span>
            )}
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={markAll}
              disabled={unread === 0}
            >
              <CheckCheck size={15} strokeWidth={1.9} aria-hidden="true" />
              Прочитать все
            </button>
          </>
        }
      />

      <div className="filter-bar" role="tablist" aria-label="Категории уведомлений">
        {FILTERS.map((item) => (
          <button
            key={item.key}
            type="button"
            role="tab"
            aria-selected={filter === item.key}
            className="filter-chip"
            data-active={filter === item.key ? "true" : undefined}
            onClick={() => setFilter(item.key)}
          >
            {item.label}
            <span>{counts[item.key]}</span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={filter === "all" ? Inbox : BellOff}
            title="Здесь пока пусто"
            text={
              filter === "all"
                ? "Новости деканата и напоминания появятся здесь."
                : "В этой категории уведомлений нет."
            }
          />
        </div>
      ) : (
        <div className="notification-groups">
          {groups.map((group) => (
            <section key={group.key} className="notification-group">
              <h2 className="notification-group-title">{group.label}</h2>
              <div className="notification-list">
                {group.items.map((item) => {
                  const due = item.dueDate ? daysUntil(item.dueDate) : null;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      className="notification-card"
                      data-unread={!item.isRead ? "true" : undefined}
                      onClick={() => markRead(item)}
                    >
                      <span className="notification-main">
                        <span className="notification-topline">
                          <span className="notification-category">
                            {categoryLabel(item.category)}
                          </span>
                          <span className="notification-time">{timeAgo(item.createdAt)}</span>
                          {!item.isRead && <span className="unread-dot" />}
                        </span>
                        <span className="notification-title">{item.title}</span>
                        <span className="notification-body">{item.body}</span>
                        {item.dueDate && (
                          <span className="notification-due">
                            до {formatDayMonth(item.dueDate)}
                            {due !== null && due >= 0 && (
                              <em>
                                {due === 0
                                  ? " · сегодня"
                                  : ` · ${due} ${daysWord(due)}`}
                              </em>
                            )}
                          </span>
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}

      <p className="notifications-note">
        Нажмите на карточку, чтобы отметить уведомление прочитанным. Счётчик в меню
        обновится сразу.
      </p>
    </div>
  );
}
