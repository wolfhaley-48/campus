import { useCallback, useEffect, useState } from "react";
import {
  ChevronRight,
  FileSearch,
  FileText,
  Plus,
  ShieldCheck,
} from "../icons";
import { useSearchParams } from "react-router-dom";
import { Link, useAppNavigate } from "../navigation";

import { NewRequestModal } from "../components/NewRequestModal";
import { PageHeader } from "../components/PageHeader";
import { EmptyState, ErrorState } from "../components/States";
import { useApi } from "../useApi";
import { formatDateTime, requestStatusTone } from "../utils";

const FILTERS = [
  { key: "all", label: "Все" },
  { key: "active", label: "В работе" },
  { key: "ready", label: "Готовые" },
];

function RequestsSkeleton() {
  return (
    <div className="page" aria-busy="true" aria-label="Загрузка заявок">
      <div className="stack" style={{ gap: 10 }}>
        <div className="skeleton" style={{ width: 90, height: 10 }} />
        <div className="skeleton" style={{ width: 220, height: 34 }} />
      </div>
      <div className="skeleton" style={{ height: 46, borderRadius: 999, width: 360 }} />
      {[0, 1, 2].map((item) => (
        <div key={item} className="skeleton" style={{ height: 120, borderRadius: 20 }} />
      ))}
    </div>
  );
}

export default function Requests() {
  const { data, loading, error, reload } = useApi("/requests");
  const [filter, setFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useAppNavigate();

  useEffect(() => {
    if (searchParams.get("new") === "1") setModalOpen(true);
  }, [searchParams]);

  const closeModal = useCallback(() => {
    setModalOpen(false);
    if (searchParams.get("new")) {
      const next = new URLSearchParams(searchParams);
      next.delete("new");
      setSearchParams(next, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  if (loading && !data) return <RequestsSkeleton />;

  if (error) {
    return (
      <div className="page">
        <PageHeader eyebrow="Сервисы" title="Заявки и справки" />
        <ErrorState onRetry={reload} />
      </div>
    );
  }

  const requests = data.requests;
  const counts = {
    all: requests.length,
    active: requests.filter((item) => ["submitted", "in_progress"].includes(item.status))
      .length,
    ready: requests.filter((item) => item.status === "ready").length,
  };
  const filtered = requests.filter((request) => {
    if (filter === "active") return ["submitted", "in_progress"].includes(request.status);
    if (filter === "ready") return request.status === "ready";
    return true;
  });
  const deliveryLabels = Object.fromEntries(
    (data.delivery || []).map((item) => [item.key, item.label]),
  );

  return (
    <div className="page">
      <PageHeader
        eyebrow="Сервисы"
        title="Заявки и справки"
        subtitle="Справки и заявления без похода в деканат. Текущий статус виден в списке, история — на странице заявки."
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setModalOpen(true)}>
            <Plus size={16} strokeWidth={2.2} aria-hidden="true" />
            Новая заявка
          </button>
        }
      />

      <div className="requests-toolbar">
        <div className="filter-bar" role="tablist" aria-label="Фильтр заявок">
          {FILTERS.map((item) => (
            <button
              key={item.key}
              type="button"
              role="tab"
              aria-selected={filter === item.key}
              className="filter-chip"
              data-active={filter === item.key ? "true" : undefined}
              onClick={() => setFilter(item.key)}
            >
              {item.label}
              <span>{counts[item.key]}</span>
            </button>
          ))}
        </div>
        <span className="requests-security">
          <ShieldCheck size={14} strokeWidth={1.9} aria-hidden="true" />
          Видны только ваши заявки
        </span>
      </div>

      {filtered.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={filter === "ready" ? FileSearch : FileText}
            title={
              filter === "all"
                ? "Заявок пока нет"
                : filter === "ready"
                  ? "Готовых заявок нет"
                  : "Нет заявок в работе"
            }
            text="Справка об обучении готовится 1–2 рабочих дня. Заявление на стипендию — до пяти."
            action={
              filter === "all" ? (
                <button
                  type="button"
                  className="btn btn-primary btn-sm"
                  onClick={() => setModalOpen(true)}
                >
                  <Plus size={14} aria-hidden="true" /> Создать заявку
                </button>
              ) : null
            }
          />
        </div>
      ) : (
        <div className="request-list">
          {filtered.map((request) => (
            <Link
              to={`/requests/${request.id}`}
              className="request-card"
              data-status={request.status}
              key={request.id}
            >
              <span className="request-main">
                <span className="request-topline">
                  <span className="request-number">{request.number}</span>
                  <span className={`pill pill-${requestStatusTone(request.status)} pill-status`}>
                    {request.statusLabel}
                  </span>
                </span>
                <span className="request-title">{request.typeLabel}</span>
                <span className="request-meta">
                  {formatDateTime(request.createdAt)} · {deliveryLabels[request.delivery] || request.delivery}
                </span>
              </span>
              <ChevronRight
                size={18}
                strokeWidth={1.9}
                className="request-chevron"
                aria-hidden="true"
              />
            </Link>
          ))}
        </div>
      )}

      <div className="card request-help">
        <div>
          <h2>Какие справки бывают</h2>
          <p>
            Справка об обучении подтверждает курс и форму обучения. Для военкомата нужна
            отдельная форма с печатью. Справка о стипендии показывает выплаты за три месяца.
          </p>
        </div>
      </div>

      {data && (
        <NewRequestModal
          open={modalOpen}
          onClose={closeModal}
          types={data.types}
          delivery={data.delivery}
          onCreated={(request) => {
            closeModal();
            navigate(`/requests/${request.id}`);
          }}
        />
      )}
    </div>
  );
}
