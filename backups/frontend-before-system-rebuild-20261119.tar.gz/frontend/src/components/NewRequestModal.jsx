import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ShieldCheck, X } from "../icons";

import { api } from "../api";
import { useAuth } from "../auth";
import { SlideToSubmit } from "../bencho/SlideToSubmit";
import { useToast } from "../toast";

export function NewRequestModal({ open, onClose, types, delivery, onCreated }) {
  const [type, setType] = useState(types?.[0]?.key || "");
  const [mode, setMode] = useState("electronic");
  const [comment, setComment] = useState("");
  const [resetKey, setResetKey] = useState(0);
  const { toast } = useToast();
  const { refreshUnread } = useAuth();
  const dialogRef = useRef(null);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (!open) return;
    setType(types?.[0]?.key || "");
    setMode("electronic");
    setComment("");
    setResetKey((value) => value + 1);
    const timer = setTimeout(() => dialogRef.current?.focus(), 80);
    return () => clearTimeout(timer);
  }, [open, types]);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        onClose();
        return;
      }
      if (event.key !== "Tab") return;

      const root = dialogRef.current;
      if (!root) return;
      const nodes = Array.from(
        root.querySelectorAll(
          'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((element) => element.getClientRects().length > 0);
      if (nodes.length === 0) {
        event.preventDefault();
        root.focus();
        return;
      }

      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || active === root)) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && active === last) {
        event.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [open, onClose]);

  const submit = async () => {
    try {
      const data = await api.post("/requests", {
        type,
        delivery: mode,
        comment,
      });
      refreshUnread();
      toast({
        kind: "success",
        title: "Заявка создана",
        body: `${data.request.number}. Статус будет обновляться в разделе «Заявки».`,
      });
      onCreated?.(data.request);
    } catch (error) {
      toast({
        kind: "error",
        title: "Не удалось создать заявку",
        body: error.message,
      });
      throw error;
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="modal-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          onMouseDown={onClose}
        >
          <motion.div
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="new-request-title"
            aria-describedby="new-request-desc"
            tabIndex={-1}
            ref={dialogRef}
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 24 }}
            transition={reducedMotion ? { duration: 0.12 } : {
              y: { type: "spring", mass: 0.5, stiffness: 100, damping: 15.56, restDelta: 0.01, restSpeed: 0.01 },
              opacity: { duration: 0.18 },
            }}
            onMouseDown={(event) => event.stopPropagation()}
          >
            <span className="modal-handle" aria-hidden="true" />

            <header className="modal-head">
              <div>
                <p className="eyebrow">Деканат</p>
                <h2 id="new-request-title">Новая заявка</h2>
                <p id="new-request-desc">
                  Выберите, что нужно, и способ получения. Заявка сразу попадёт в работу.
                </p>
              </div>
              <button
                type="button"
                className="icon-btn"
                onClick={onClose}
                aria-label="Закрыть"
              >
                <X size={18} strokeWidth={2} aria-hidden="true" />
              </button>
            </header>

            <div className="modal-body">
              <span className="field-label">Что нужно</span>
              <div className="request-type-grid" role="radiogroup" aria-label="Тип заявки">
                {(types || []).map((item) => {
                  const active = item.key === type;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      className="type-option"
                      data-active={active ? "true" : undefined}
                      onClick={() => {
                        setType(item.key);
                        setResetKey((value) => value + 1);
                      }}
                    >
                      <span className="type-option-radio" aria-hidden="true" />
                      <span className="type-option-text">
                        <b>{item.label}</b>
                        <small>{item.description}</small>
                      </span>
                      <span className="type-option-eta">{item.eta}</span>
                    </button>
                  );
                })}
              </div>

              <span className="field-label">Как получить</span>
              <div className="delivery-toggle" role="radiogroup" aria-label="Способ получения">
                {(delivery || []).map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    role="radio"
                    aria-checked={mode === item.key}
                    className="delivery-option"
                    data-active={mode === item.key ? "true" : undefined}
                    onClick={() => setMode(item.key)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <label className="field-label" htmlFor="request-comment">
                Комментарий <span>необязательно</span>
              </label>
              <textarea
                id="request-comment"
                className="textarea"
                maxLength={600}
                value={comment}
                onChange={(event) => setComment(event.target.value)}
                placeholder="Например: нужна справка для банка, прошу подготовить к пятнице"
                rows={3}
              />
              <span className="char-count">{comment.length} / 600</span>

              <div className="modal-note">
                <ShieldCheck size={15} strokeWidth={1.9} aria-hidden="true" />
                Заявка уйдёт в деканат от вашего имени. Другие студенты её не увидят.
              </div>
            </div>

            <footer className="modal-foot">
              <SlideToSubmit
                key={resetKey}
                onConfirm={submit}
                label="Сдвиньте, чтобы отправить"
                doneLabel="Заявка создана"
              />
              <p className="modal-disclaimer">
                В демо статус заявки не меняется автоматически. Текущий статус всегда
                виден в разделе «Заявки».
              </p>
            </footer>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
